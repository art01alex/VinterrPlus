const OptBlock = (): JSX.Element => {

	return <section className="opt_section section">
		<div className="section-title">
			<h2 className='title'>ПРОИЗВОДСТВО ОДЕЖДЫ <br /> ПОД ВАШИМ БРЕНДОМ</h2>
		</div>
	</section>;

};

export default OptBlock;